Please see the Doc/Manual/Windows.html file in the main manual for instructions for using and installing SWIG on Windows including running the examples.
