<?php

# This code is inserted into example.php
echo "This is include.php\n";
