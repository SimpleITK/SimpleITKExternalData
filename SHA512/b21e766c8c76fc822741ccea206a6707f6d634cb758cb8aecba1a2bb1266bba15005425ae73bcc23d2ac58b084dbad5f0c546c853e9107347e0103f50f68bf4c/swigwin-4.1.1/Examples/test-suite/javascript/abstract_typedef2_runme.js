var abstract_typedef2 = require("abstract_typedef2");

var a = new abstract_typedef2.A_UF();

if (a == undefined)
  throw "Error";
