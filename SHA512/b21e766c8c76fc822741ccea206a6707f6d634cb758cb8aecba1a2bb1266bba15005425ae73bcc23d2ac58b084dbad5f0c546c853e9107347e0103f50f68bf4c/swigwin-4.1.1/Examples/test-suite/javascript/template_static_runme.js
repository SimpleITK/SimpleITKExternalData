var template_static = require("template_static");

template_static.Foo.bar_double(1);
