var using1 = require("using1");

if (using1.spam(37) != 37)
    throw "RuntimeError";
