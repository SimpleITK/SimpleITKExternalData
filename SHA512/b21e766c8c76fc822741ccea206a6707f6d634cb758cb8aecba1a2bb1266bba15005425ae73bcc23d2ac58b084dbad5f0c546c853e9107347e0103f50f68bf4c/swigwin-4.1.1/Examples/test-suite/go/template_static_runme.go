package main

import . "swigtests/template_static"

func main() {
	FooBar_double(1)
}
