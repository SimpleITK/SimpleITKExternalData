package main

import "swigtests/keyword_rename_c"

func main() {
	keyword_rename_c.Xgo(1)
	keyword_rename_c.Xchan(1)
}
