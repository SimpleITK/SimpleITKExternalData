package main

import "swigtests/namespace_virtual_method"

func main() {
	_ = namespace_virtual_method.NewSpam()
}
