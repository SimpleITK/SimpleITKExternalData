package main

import "swigtests/struct_rename"

func main() {
	_ = struct_rename.NewBar()
}
