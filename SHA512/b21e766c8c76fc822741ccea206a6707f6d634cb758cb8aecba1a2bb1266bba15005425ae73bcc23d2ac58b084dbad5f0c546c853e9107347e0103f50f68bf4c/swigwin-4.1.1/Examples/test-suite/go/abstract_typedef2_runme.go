package main

import "swigtests/abstract_typedef2"

func main() {
	abstract_typedef2.NewA_UF()
}
