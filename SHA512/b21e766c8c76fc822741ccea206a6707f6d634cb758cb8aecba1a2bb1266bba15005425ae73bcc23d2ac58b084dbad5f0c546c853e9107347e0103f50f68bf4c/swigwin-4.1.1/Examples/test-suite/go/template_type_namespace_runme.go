package main

import . "swigtests/template_type_namespace"

func main() {
	if Foo().Get(0) == "" {
	}
}
