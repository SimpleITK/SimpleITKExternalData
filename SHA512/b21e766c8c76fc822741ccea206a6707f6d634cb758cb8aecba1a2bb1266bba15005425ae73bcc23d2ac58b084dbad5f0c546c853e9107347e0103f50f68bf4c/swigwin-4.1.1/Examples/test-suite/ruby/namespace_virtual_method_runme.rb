#!/usr/bin/env ruby
#
# This test implementation is directly derived from its Python counterpart.
#

require 'namespace_virtual_method'

x = Namespace_virtual_method::Spam.new
