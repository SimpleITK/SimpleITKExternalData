#ifndef PKG2_FOO_HPP
#define PKG2_FOO_HPP
#include "../pkg1/foo.hpp"
struct Pkg2_Foo : public Pkg1_Foo{};
#endif /* PKG2_FOO_HPP */
