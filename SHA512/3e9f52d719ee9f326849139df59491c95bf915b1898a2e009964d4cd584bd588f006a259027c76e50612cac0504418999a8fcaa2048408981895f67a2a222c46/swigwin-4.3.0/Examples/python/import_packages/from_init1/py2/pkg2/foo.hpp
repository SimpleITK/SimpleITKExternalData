#ifndef PY2_PKG2_FOO_HPP
#define PY2_PKG2_FOO_HPP
struct Pkg2_Foo {};
#endif /* PY2_PKG2_FOO_HPP */
